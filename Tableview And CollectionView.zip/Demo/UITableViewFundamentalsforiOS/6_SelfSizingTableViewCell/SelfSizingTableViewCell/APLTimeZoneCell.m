
/*
 Copyright (C) 2016 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 A simple UITableViewCell subclass that provides references to its subviews.
 */

#import "APLTimeZoneCell.h"

@implementation APLTimeZoneCell

@end
